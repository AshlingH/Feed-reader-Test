 Feed Reader Testing


Project Submission by: Aisling Hennessy


Project Overview


In this project you are supplied a web-based application that reads RSS feeds by Udacity. The original developer included Jasmine and provided the first test.

The original Project Instructions can be found here:


Project 4 Instructions/Guidelines:

Instructions
In order to view the projects and run the tests, simply click on the download button above and extract the zip file download. Then, double click on the index.html to open the project in your web browser of choice.

Dependencies
The project file contains all the necessary CDNs in the index file (jQuery, jasmine)

Contributions
 I was the only person working on this project. All code is my own.

Licensing
This project is licensed under the Creative Commons Licensing. You are free to:

Share - copy and redistribute the matertial in any medium or format

Adapt - remix, transform, and build upon the material for any purpose, even commercially.
